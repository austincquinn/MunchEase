package edu.ucsb.munchease.data;

public class MunchEaseValues {
    public final static int PARTY_ID_LENGTH = 6;
}
